#ifndef MYLIB_H
#define MYLIB_H

void *memalloc(unsigned long size);
int memfree(void *ptr);

#endif 
