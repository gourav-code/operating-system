#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main(int arg_cnt, char* arg_vec[]) {
    if (arg_cnt < 2) {
        fprintf(stderr, "Unable to execute\n");
        return 1;
    }

    long int val = atoi(arg_vec[arg_cnt - 1]);
    val = val * 2;

    if (arg_cnt == 2) {
        printf("%ld\n", val);
    } else {
        char a[100] = "./";
        strcat(a, arg_vec[1]);
        char str[100];
        snprintf(str, sizeof(str), "%ld", val);

        // Free the old memory before allocating new memory for arg_vec[arg_cnt-1]
        // free(arg_vec[arg_cnt - 1]);

        int len2 = strlen(str);
        arg_vec[arg_cnt - 1] = malloc(len2 + 1);
        strcpy(arg_vec[arg_cnt - 1], str);

        execvp(a,(arg_vec + 1));


        // execvp only returns if an error occurs
        perror("execvp");
        return 1;
    }

    return 0;
}
