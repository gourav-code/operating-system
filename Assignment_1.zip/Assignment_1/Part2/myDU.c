#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include <sys/wait.h>
#include <sys/stat.h>

char **lsResult;
char *executableFileName;
unsigned long result=0;

unsigned long giveSize(int columLen,char *path) {
    unsigned long value = 0;
    char *delimiter1 = " ";
    char *fileNameBuff = (char *)malloc(5000*sizeof(char));
    char *templsResult = (char *)malloc(5000*sizeof(char));
    for(int i=0;i<columLen;++i){
        memset(templsResult,0,strlen(templsResult));
        strncpy(templsResult,lsResult[i],strlen(lsResult[i])+1);
        char *portion = strtok(templsResult,delimiter1); 
        if(portion[0] == 'l' || portion[1] == 'l')
                continue;
        int whiteSpace = 1;
        while (portion != NULL)
        {
            /* code */
            
            memset(fileNameBuff,0,strlen(fileNameBuff));
            strncpy(fileNameBuff,portion,strlen(portion)+1);
            portion = strtok(NULL,delimiter1);
            whiteSpace++;
            while (whiteSpace > 9)
            {
                /* code */
                if(portion == NULL) 
                    break;
                
                char *temp = "";
                strcat(fileNameBuff,temp);
                strcat(portion,temp);
                temp = " ";
                strcat(fileNameBuff,temp);
                strcat(fileNameBuff,portion);
                whiteSpace++;
                portion = strtok(NULL,delimiter1);
            }
        }
        struct stat sbuf1;
        char *tempPath = malloc(5000*sizeof(char));
        strncpy(tempPath,path,strlen(path)+1);
        char *tmp = "/";
        // printf("%d, tempPath:%s\n",__LINE__,tempPath);
        // printf("working on slash:%c\n",tempPath[strlen(tempPath)-1]);
        // printf("%d, flenamebuff:%s\n",__LINE__,fileNameBuff);
        if(tempPath[strlen(tempPath)-1] != '/')
            strcat(tempPath,tmp);
        fileNameBuff = strcat(tempPath,fileNameBuff);

        // printf("%d filenamebuff:%s\n",__LINE__,fileNameBuff);
        stat(fileNameBuff,&sbuf1);
        // printf("inode = %ld size=%ld\n",sbuf1.st_ino,sbuf1.st_size);
        if(sbuf1.st_ino != 0)
            value += sbuf1.st_size;
        fileNameBuff[0] = '\0';
        
    }
    // printf("%d value:%ld\n",__LINE__,value);
    free(fileNameBuff);
    free(templsResult);
    return value;
}

unsigned long linkgiveSize(char *filePath,int columLen) {
    unsigned long value = 0;
    char *delimiter1 = " ";
    char *fileNameBuff = (char *)malloc(5000*sizeof(char));
    char *templsResult = (char *)malloc(5000*sizeof(char));
    for(int i=0;i<columLen;++i){
        memset(templsResult,0,strlen(templsResult));
        strncpy(templsResult,lsResult[i],strlen(lsResult[i])+1);
        char *portion = strtok(templsResult,delimiter1); 
        if(portion[0] == 'l' || portion[1] != 'l')
                continue;
        int whiteSpace = 1;
        while (portion != NULL)
        {
            /* code */
            
            memset(fileNameBuff,0,strlen(fileNameBuff));
            strncpy(fileNameBuff,portion,strlen(portion)+1);
            portion = strtok(NULL,delimiter1);
            whiteSpace++;
            while (whiteSpace > 9)
            {
                /* code */
                if(portion == NULL) 
                    break;
                
                char *temp = "";
                strcat(fileNameBuff,temp);
                strcat(portion,temp);
                temp = " ";
                strcat(fileNameBuff,temp);
                strcat(fileNameBuff,portion);
                temp="";
                strcat(fileNameBuff,temp);
                whiteSpace++;
                portion = strtok(NULL,delimiter1);
            }
        }
        // printf("%s\n",fileNameBuff);
        // printf("%d filePath:%s\n",__LINE__,filePath);
        char *tempFilePath;
        tempFilePath = (char *)malloc(5000*sizeof(char));
        strncpy(tempFilePath,filePath,strlen(filePath)+1);
        tempFilePath[strlen(filePath)+1] = '\0';
        strcat(tempFilePath,fileNameBuff);
        // printf("%d fileNameBuff:%s\n",__LINE__,tempFilePath);
        struct stat sbuf1;
        stat(tempFilePath,&sbuf1);
        // printf("inode = %ld size=%ld\n",sbuf1.st_ino,sbuf1.st_size);
        if(sbuf1.st_ino != 0)
            value += sbuf1.st_size;
        fileNameBuff[0] = '\0';
        free(tempFilePath);
        
    }
    // printf("%d ,value:%ld\n",__LINE__,value);
    free(fileNameBuff);
    free(templsResult);
    
    return value;
}
char * dirfileName(char *dirdiscription){

    char *delimiter1 = " ";
    char *dirNameBuff = (char *)malloc(5000*sizeof(char));
    char *tempPortion = (char *)malloc(5000*sizeof(char));

    strncpy(tempPortion,dirdiscription,strlen(dirdiscription)+1);
    char *portion = strtok(tempPortion,delimiter1);
    int whiteSpace = 1;
    while (portion != NULL)
    {
        /* code */
        memset(dirNameBuff,0,strlen(dirNameBuff));
        strncpy(dirNameBuff,portion,strlen(portion)+1);
        portion = strtok(NULL,delimiter1);
        whiteSpace++;
        while (whiteSpace > 9)
        {
            /* code */
            if(portion == NULL)
                break;

            char *temp = "";
            strcat(dirNameBuff,temp);
            strcat(portion,temp);
            temp = " ";
            strcat(dirNameBuff,temp);
            strcat(dirNameBuff,portion);
            temp="";
            strcat(dirNameBuff,temp);
            whiteSpace++;
            portion = strtok(NULL,delimiter1);
            
        }
        
    }
    // printf("%d, dirName:%s\n",__LINE__,dirNameBuff);
    free(tempPortion);
    return dirNameBuff;      //to be completed
}

char * fileName(char *containListDiscription){
    char *delimiter1 = " ";
    char *fileNameBuff = (char *)malloc(5000*sizeof(char));
    char *portion = strtok(containListDiscription,delimiter1); 
    int whiteSpace = 1;
    char *tmp = "->";
    while (portion != NULL)
    {
        /* code */
        
        memset(fileNameBuff,0,strlen(fileNameBuff));
        strncpy(fileNameBuff,portion,strlen(portion));
        portion = strtok(NULL,delimiter1);
    }
    memset(containListDiscription,0,strlen(containListDiscription));
    tmp = "lp";
    strncpy(containListDiscription,tmp,strlen(tmp)+1);
    containListDiscription[2] = '\0';
    // printf("fileNameBuff link: %s\n",fileNameBuff);
    return fileNameBuff;
}
unsigned long dirSize(char *path, char *dirName){
    unsigned long value = 0;
    int temp;
    if(path[strlen(path)-1] != '/' ){
        char *tmp = "/";
        strcat(path,tmp);
    }
    int fd1[2];
    // printf("%d, dirNameBuff:%s\n",__LINE__,dirNameBuff);
    // printf("%d, path:%s\n",__LINE__,path);
    strcat(path,dirName);

    if(pipe(fd1) < 0){
        // printf("%s : %d pipe. Unable to execute.",__FILE__,__LINE__);
        exit(-1);
    } 
    // printf("%d temp:%d\n",__LINE__,temp) ;
    temp = fork();
    // printf("%d temp:%d\n",__LINE__,temp) ;
    if(temp < 0){
        // printf("%s : %d fork unable to execute.",__FILE__,__LINE__);
        exit(-1);
    }

    if(!temp){
        close(fd1[0]);
        close(1);
        dup(fd1[1]);
        execl(executableFileName, executableFileName,path, NULL);
        // printf("%s : %d exec unable to execute.",__FILE__,__LINE__);
        exit(-1);
    }

    int childPid = waitpid(temp, NULL, 0);

    close(fd1[1]); 
    char readBuffer1[5000];
    int nbytes = read(fd1[0],readBuffer1, sizeof(readBuffer1)+1);

    // printf("%d, nbytes:%d, path:%s ,readbuffer:%s , size:%lu\n",__LINE__,nbytes,path,readBuffer1,sizeof(readBuffer1));
    close(fd1[0]);
    value = atoi(readBuffer1);
    return value;
}

void linkDirFileNameAdd(char *linkDir, int *columLen){
    int fd[2];
    int readbufferSize = 4000;
    int temp;
    unsigned long value = 0;
    if(pipe(fd) < 0){
        // printf("%s : %d pipe. Unable to execute.",__FILE__,__LINE__);
        exit(-1);
    }

    temp = fork();

    if(temp < 0){
        // printf("%s : %d fork unable to execute.",__FILE__,__LINE__);
        exit(-1);
    }

    if(!temp){
        close(fd[0]);
        close(1);
        dup(fd[1]);
        execl("/bin/ls", "ls","-ltr", linkDir, NULL);
        // printf("%s : %d exec unable to execute.",__FILE__,__LINE__);
        exit(-1);
    }
    // printf("%d, linkDir:%s\n",__LINE__,linkDir);
    int childPid = wait(&temp);

    close(fd[1]);   //file descriptor for writing to pipe line
    char readbuffer[readbufferSize];
    int nbytes;         //does nothing
    nbytes = read(fd[0],readbuffer, sizeof(readbuffer)+1);
    close(fd[0]);
    char *delimiter1 = "\n";
    char *portion = (char *)malloc(5000*sizeof(char));
    portion = strtok(readbuffer, delimiter1);
    
    portion = strtok(NULL, delimiter1);
    // printf("%d first line:%s\n",__LINE__,portion);
    char **linklsResult;
    linklsResult = (char **)malloc(1*sizeof(char *));
    int linkcolumnLen=0;
    char *dirNameBuff;
    while (portion != NULL)
    {
        /* code */
        if(portion[0] == 'l'){
            *(linklsResult+linkcolumnLen) = (char*)malloc((strlen(portion)+1)*sizeof(char));
            strncpy(linklsResult[linkcolumnLen],portion,strlen(portion)+1);
            ++linkcolumnLen;
            portion = strtok(NULL, delimiter1);    
            linklsResult = realloc(linklsResult,(linkcolumnLen+1)*sizeof(char *));
            continue;
        }
        // printf("%d first line:%s\n",__LINE__,portion);
        portion[1] = 'l';

        if(portion[0] == 'd' && portion[1]== 'l'){
            dirNameBuff = dirfileName(portion);
            result += dirSize(linkDir,dirNameBuff);
        }
            

        
        *(lsResult+(*columLen)) = (char*)malloc((strlen(portion)+1)*sizeof(char));
        strncpy(lsResult[*columLen],portion,strlen(portion)+1);
        
        ++(*columLen);
        portion = strtok(NULL, delimiter1);
        // printf("columnLen:%d portion:%s\n",(*columLen),portion);
        lsResult = realloc(lsResult,((*columLen)+1)*sizeof(char *));        //realloc increase whole array by given amount
        
    }
    // printf("-----------------%d-----------------------\n",__LINE__);
    char *fileNameBuff;
    for(int i=0;i<linkcolumnLen;++i){
        char *tempNew = malloc(5000*sizeof(char));
        strncpy(tempNew,linklsResult[i],strlen(linklsResult[i])+1);
        if(tempNew[0] == 'l' && tempNew[1] != 'p'){
            fileNameBuff = fileName(tempNew);
            // printf("%d linklsResult:%s\n",__LINE__,linklsResult[i]);
            // printf("%d linkFileName:%s\n",__LINE__,fileNameBuff);
            linkDirFileNameAdd(fileNameBuff,columLen);
        }

    }

    free(portion);
    free(linklsResult);
}

unsigned long main(int argc, char* argv[]){
    int fd[2];
    int readbufferSize = 5000;
    int temp;
    executableFileName = (char *)malloc(5000*sizeof(char));
    memset(executableFileName,0,strlen(executableFileName));
    strncpy(executableFileName,argv[0],strlen(argv[0])+1);
    // printf("%s\n",argv[1]);
    if(pipe(fd) < 0){
        // printf("%s : %d pipe. Unable to execute.",__FILE__,__LINE__);
        exit(-1);
    }

    temp = fork();

    if(temp < 0){
        // printf("%s : %d fork unable to execute.",__FILE__,__LINE__);
        exit(-1);
    }

    if(!temp){
        close(fd[0]);
        close(1);
        dup(fd[1]);
        execl("/bin/ls", "ls","-ltr", argv[1], NULL);
        // printf("%s : %d exec unable to execute.",__FILE__,__LINE__);
        exit(-1);
    }

    int childPid = wait(&temp);

    close(fd[1]);   //file descriptor for writing to pipe line
    char readbuffer[readbufferSize];
    int nbytes;         //does nothing
    nbytes = read(fd[0],readbuffer, sizeof(readbuffer)+1);
    close(fd[0]);
    // printf("%d, readbuffer:%s\n",__LINE__,readbuffer);
    char *delimiter1 = "\n";
    char *portion = (char *)malloc(5000*sizeof(char));
    portion = strtok(readbuffer, delimiter1);
    
    portion = strtok(NULL, delimiter1);

    int colLen = 0;
    
    lsResult = (char **)malloc(1*sizeof(char *));

    while (portion != NULL)
    {
        /* code */
        char *tmp = "\n";
        if(!strcmp(portion,tmp)){
            continue;
        }
        *(lsResult+colLen) = (char*)malloc((strlen(portion)+1)*sizeof(char));
        strncpy(lsResult[colLen],portion,strlen(portion)+1);
        // printf("columnLen:%d portion:%s\n",colLen,portion);
        ++colLen;
        portion = strtok(NULL, delimiter1);
        
        lsResult = realloc(lsResult,(colLen+1)*sizeof(char *));        //realloc increase whole array by given amount       
    }
    
    char *fileNameBuff;
    for(int i=0;i<colLen;++i){
        char *tempNew = malloc(5000*sizeof(char));
        strncpy(tempNew,lsResult[i],strlen(lsResult[i])+1);
        if(tempNew[0] == 'l' && tempNew[1] != 'p'){
            // printf("%d %s\n",__LINE__,tempNew);
            // printf("%d lsResult:%s\n",__LINE__,lsResult[i]);
            fileNameBuff = fileName(tempNew);
            // printf("%d lsResult:%s\n",__LINE__,lsResult[i]);
            // printf("%d linkFile Name:%s\n",__LINE__,fileNameBuff);
            linkDirFileNameAdd(fileNameBuff,&colLen);
            result += linkgiveSize(fileNameBuff,colLen);
            // printf("%d result:%ld\n",__LINE__,result);
        }
        free(tempNew);

    }
    for(int i=0;i<colLen;++i){
        // printf("%d, lsResult:%s\n",__LINE__,lsResult[i]);
    }
    // printf("%d\n",colLen);
    // printf("%d, result after link calculation:%ld\n",__LINE__,result);
    result += giveSize(colLen,argv[1]);
    // // printf("%d, colLen:%d\n",__LINE__,colLen);
    // printf("%d ,result:%ld\n",__LINE__,result);
    // printf("%ld\n",result);
    // printf("%d,------------------------------------------------ everything is fine----------------------------------------------\n",__LINE__);


    //size of files inside directory
    char *dirNameBuff;
    
    for(int i=0;i<colLen;++i){
        int fd1[2];
        char readBuffer1[readbufferSize];
        if(lsResult[i][0] != 'd'){
            continue;
        }
        if(lsResult[i][0] == 'd' && lsResult[i][1] == 'l'){
            continue;
        }
        char *tempNew1 = malloc(5000*sizeof(char));
        strncpy(tempNew1,lsResult[i],strlen(lsResult[i])+1);
        lsResult[i][1] = 'p';
        dirNameBuff = dirfileName(tempNew1);
        char *path = malloc(5000*sizeof(char));
        strncpy(path,argv[1],strlen(argv[1])+1);
        result += dirSize(path,dirNameBuff);

    }
    printf("%ld\n",result);
    return result;
}

